from .advocacy_campaign import AdvocacyCampaign
from .advocacy_campaigns import AdvocacyCampaigns
