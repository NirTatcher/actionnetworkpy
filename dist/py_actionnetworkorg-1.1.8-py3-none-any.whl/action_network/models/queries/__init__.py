from .query import Query
from .queries import Queries